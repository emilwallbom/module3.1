@echo off
setlocal
cd /d "%~dp0"
"runtime\python\python.exe" -I scripts\launch.py play --terminal-mode paper-hard
if errorlevel 1 pause
