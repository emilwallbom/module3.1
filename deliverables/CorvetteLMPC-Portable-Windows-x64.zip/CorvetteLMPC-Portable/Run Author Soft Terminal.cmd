@echo off
setlocal
cd /d "%~dp0"
"runtime\python\python.exe" -I scripts\launch.py play --terminal-mode author-soft
if errorlevel 1 pause
