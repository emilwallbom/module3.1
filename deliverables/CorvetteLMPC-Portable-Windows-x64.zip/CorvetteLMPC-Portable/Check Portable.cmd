@echo off
setlocal
cd /d "%~dp0"
"runtime\python\python.exe" -I scripts\portable_check.py
pause
