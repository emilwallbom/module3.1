@echo off
setlocal
cd /d "%~dp0"
"runtime\python\python.exe" -I scripts\launch.py play
if errorlevel 1 pause
