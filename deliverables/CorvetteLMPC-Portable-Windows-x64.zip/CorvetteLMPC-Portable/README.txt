CORVETTE C4 LMPC — PORTABLE WINDOWS x64

1. Extract the ENTIRE ZIP into a writable folder, such as your Desktop.
2. Open that extracted folder and double-click Run Simulator.cmd.
   Do not run from inside the ZIP. Keep all its folders together.

Windows 10/11 x64 and a Direct3D 11 graphics driver are required.
No Unity Editor, Unity login, separate Python installation, administrator
installation, or internet connection is required to run this package.

Watch Demo.cmd opens the included 40-learning-lap run read-only.
LEARN / DRIVE / REPLAY switch modes. LOAD SAVED restores your local run.
LOAD DEMO opens the current benchmark; OLD v1 opens the historical demo.
Manual laps and replays never enter training data.

W/Up: throttle   S/Down/Space: brake   A/D/arrows: steer
C: camera   Tab: focus car/ghost   G: ghosts   L: learning overlays
P: pause   R: reset/retry   M: Learn/Drive   H/Escape: help

Only one copy can use localhost port 8765 at a time; close any other
simulator folder before opening this one. Launching again in this folder
restores its current window. The game EXE alone does not start Python:
use Run Simulator.cmd. Close the game normally to stop its helper.

Your checkpoints and manual recordings stay under recordings/racing-v3/live.
Portable logs and configurable caches stay under artifacts and .cache.
Windows/Unity may also create normal user preferences and player logs.
Check Portable.cmd verifies private Python, dependencies and MPC solving.

The physics and MPC match the source project. The robust-lmpc default is
an explicitly adapted full-size controller; see docs/PAPER_ALIGNMENT.md.
The car is an original simplified C4-style model, not an imported asset.

Dependency versions and every shipped file hash are in portable-manifest.json.
Python's license is runtime/python/LICENSE.txt. Each Python dependency retains
its license files in runtime/python/Lib/site-packages/<package>.dist-info.
Microsoft app-local C/C++ release runtime DLLs retain Microsoft's copyright;
deployment reference: https://learn.microsoft.com/en-us/cpp/windows/redistributing-visual-cpp-files
Unity player runtime remains subject to Unity's terms; no Editor/account/
license credentials are included. See THIRD_PARTY_NOTICES.md for attribution.
